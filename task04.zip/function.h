#pragma once
#include <iostream>
#include <string>
#include <bitset>
#include <fstream>
#include <stdint.h>
#include <iomanip>
using namespace std;

void chose();
void writeIntOverK(string file_name);
void writeInt2Comp(string file_name);
/*void writeReal(string file_name);
void Read(int op, string file_name);*/
bool writeLEInt(int64_t Int, int n, string file_name);

bool writeLEFloat(float real, string file_name);

bool writeLEDouble(double real, string file_name);
bool writeBEInt(int64_t Int, int n, string file_name);
bool writeBEInt(int64_t Int, int n, string file_name);
bool writeBEFloat(float a, string file_name);
bool writeBEDouble(double a, string file_name);
void writeIntOverK(string file_name);
void writeInt2Comp(string file_name);
void writeReal(string file_name);
bool readLEInt(int64_t &Int, int n, string file_name);
void writeString(string file_name);
void readString(string file_name);
bool readLEFloat(float real, string file_name);
bool readLEDouble(double real, string file_name);
bool readBEFloat(float a, string file_name);
bool readBEFloat(float a, string file_name);
bool readLEInt(int64_t &Int, int n, string file_name);
bool readBEInt(int64_t &Int, int n, string file_name);
void readString(string file_name);

void readIntOverK(string file_name);

void readInt2Comp(string file_name);