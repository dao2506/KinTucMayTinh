#include "function.h"

int main() {

	chose();
	
	system("pause");
	return 0;
}