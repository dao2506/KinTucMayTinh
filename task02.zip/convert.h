#pragma once
#include <iostream>
#include <string>
#include <bitset>
#include <fstream>
#include <stdint.h>
#include <vector>
using namespace std;

vector<unsigned short> magture(long Int, vector<unsigned short> &mod);
char epKieuReverse(int num);
void reverse(char* str);
char* fromDeci(char *stringAfter, int base, long inputNum);
