#pragma once
#include <string>
#include <iostream>
#include <bitset>
#include <fstream>
#include <vector>
#include "IntNum.h"
using namespace std;

string input();
void xu_li(string &str);
void XuLiNguyen(string &str);
void XuLiThuc(string &str);
