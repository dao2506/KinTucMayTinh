#include "function.h"

int main() {

	string str = input();
	xu_li(str);
	system("pause");
	return 0;
}