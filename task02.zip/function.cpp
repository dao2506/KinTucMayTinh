#include "function.h"

const char cache[] = "cache.bin";

string input()
{
	cout << "Input: ";
	string temp;
	getline(cin, temp);
	return temp;
}

void xu_li(string &str)
{
	int viTriDauCham = str.find(".");
	bool koDauCham = (viTriDauCham == string::npos);
	//if is koCoDauCham => ep kieu long long / ep kieu int => cout giong tra sua
		// bitset <N> (base_10_int) << '\n';
	if (koDauCham)
		XuLiNguyen(str);
	else
		XuLiThuc(str);
	//if is coDauCham => ep ve double => luc cout thi ep float
}


void XuLiNguyen(string &str) 
{
	int N;
	cout << "N= ";
	cin >> N;
	OnlyForInt(str, N);
}

void XuLiThuc(string &str)
{
}


void OnlyForInt(string &str,int N) 
{
	IntNum Result(str);
	Result.output(N);
}