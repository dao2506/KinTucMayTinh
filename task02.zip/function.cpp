#include "function.h"

const char cache[] = "cache.bin";

string input()
{
	cout << "Input: ";
	string temp;
	getline(cin, temp);
	return temp;
}

void xu_li(string &str)
{
	int viTriDauCham = str.find(".");
	bool koDauCham = (viTriDauCham == string::npos);
	//if is koCoDauCham => ep kieu long long / ep kieu int => cout giong tra sua
		// bitset <N> (base_10_int) << '\n';
	if (koDauCham)
		XuLiNguyen(str);
	else
		XuLiThuc(str);
	//if is coDauCham => ep ve double => luc cout thi ep float
}


void XuLiNguyen(string &str) 
{
	int N;
	cout << "Float: ";
	char Result[34];
	ConvertRealToFloat(str, Result);
	long int ResultA= changeIntoBase10(Result,2);
	cout << hex << ResultA;

	cout << "\nDouble: ";
	char Result2[66];
	ConvertRealToDouble(str, Result2);
	long long int ResultB = changeIntoBase10(Result2, 2);
	cout << hex << ResultB;
	
	
	
	//	cout << "N= ";
//	cin >> N;
//	OnlyForInt(str, N);
}

void XuLiThuc(string &str)
{
	
}

void ConvertRealToFloat(string &str, char* result) 
{
	float real = stof(str);
	//bit dau
	result[0] = real > 0 ? '0' : '1';
	real *= real > 0 ? 1 : -1;
	//bit mu
	long int Fraction = (long int)real;
	char s1[32];
	fromDeci(s1, 2, Fraction);
		
	int E1 = 24 - strlen(s1);
	int E = 127 + (23 - E1);// E in 2^E
	fromDeci(s1, 2, E);
	for (int i = 0; i < strlen(s1) || i <= 9; ++i)
		result[1 + i] = s1[i];
		 
	//bit luong
	real *= pow(2, E1);
	Fraction = (long int)real;
	fromDeci(s1, 2, Fraction);
	//xoa s1[0], xoa 1,......
	for (int i = 1; i < strlen(s1) || i < strlen(result) ; ++i)
		result[8+i] = s1[i];
	for (int i = strlen(s1); i < strlen(result); ++i)
		result[i] = '0';
	result[32] = '\0';
}
void OnlyForInt(string &str, int N)
{
	IntNum Result(str);
	Result.output();
}

void ConvertRealToDouble(string &str, char* result)
{
	double real = stod(str);
	//bit dau
	result[0] = real > 0 ? '0' : '1';
	real *= real > 0 ? 1 : -1;
	//bit mu
	long long int Fraction = (long long int)real;
	char s1[64];
	fromDeci(s1, 2, Fraction);

	int E1 = 53 - strlen(s1);
	int E = 1023 + (52 - E1);// E in 2^E
	fromDeci(s1, 2, E);
	for (int i = 0; i < strlen(s1) || i <= 12; ++i)
		result[1 + i] = s1[i];

	//bit luong
	real *= pow(2, E1);
	Fraction = (long long int)real;
	fromDeci(s1, 2, Fraction);
	//xoa s1[0], xoa 1,......
	for (int i = 1; i < strlen(s1); ++i)
		result[12+i] = s1[i];
	for (int i = strlen(s1); i < strlen(result); ++i)
		result[i] = '0';
	result[64] = '\0';
}

