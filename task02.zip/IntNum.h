
#pragma once
#include <iostream>
#include <string>
#include <bitset>
#include <fstream>
#include <stdint.h>
#include <iomanip>
using namespace std;

class IntNum 
{
	long int base_10_int;
	char sign;
	long int SignMagnitude;
	//uint_32 
public:
	IntNum(string std);
	IntNum();
	~IntNum();
	bool input();
	void outputBase();
	void output();
	int &overK();
	int oneComplement();
	int twoComplement();
	float singlePrecisionfloat();
	int saveFile();
	int saveFile(string file_name);
	friend IntNum &operator-(IntNum& a, IntNum b);
	friend istream &operator>>(istream & ist, IntNum a);
};

