#include "function.h"

const char cache[] = "cache.bin";

int menu()
{
	system("cls");
	cout << "Choice type?\n";
	cout << "1. Write Integer over K, size: N byte,  LE or BE \n";
	cout << "2. Read Integer over K, size: N byte,  LE or BE \n";
	cout << "3. Write Interger Two Complement,size: N byte, LE or BE \n";
	cout << "4. Read Interger Two Complement,size: N byte, LE or BE \n";
	cout << "5. Write Floating percion point number, size: 4 / 8 byte LE or BE\n";
	cout << "6. Read Floating percion point number, size: 4 / 8 byte LE or BE\n";
	cout << "7. Write ASCII /UTF8 /UTF16 String LE or BE \n ";
	cout << "8. Read ASCII /UTF8 /UTF16 String LE or BE \n ";
	cout << "0. Exit\nYour choise:-> ";
	int temp;
	cin >> temp;
	return temp;
}

void chose()
{
	cout << "What file?\n->";
	//cin.ignore();
	string file_name;
	getline(cin,file_name);
	int option= menu();
	while (option)	{
		//xu_li
		switch (option)
		{
		case 1: 
			writeIntOverK(file_name);
			break;
		case 3:
			writeInt2Comp(file_name);
			break;
		case 5:
			writeReal(file_name);
			break;
		case 7:
			writeString(file_name);
			break;
		case 2:
			readIntOverK(file_name);
			break;
		case 4:
			readInt2Comp(file_name);
			break;
		case 6:

		case 8:	
			readString(file_name);
			break;
		}
		option = menu();
	}
	cout << "\n GOODBYE!";
	return;
}

bool writeLEInt(int64_t Int, int n, string file_name)
{
	ofstream fout(file_name, ios::out | ios::binary | ios::app);
	fout.write((char*)& Int, n);
	fout.close();
	return true;
}
bool writeLEFloat(float real, string file_name)
{
	ofstream fout(file_name, ios::out | ios::binary | ios::app);
	fout.write((char*)& real, sizeof(real));
	fout.close();
	return true;
}
bool writeLEDouble(double real, string file_name)
{
	ofstream fout(file_name, ios::out | ios::binary | ios::app);
	fout.write((char*)& real, sizeof(real));
	fout.close();
	return true;
}
bool writeBEInt(int64_t Int, int n, string file_name)
{
	//khay nho tam
	ofstream fout(cache, ios::out | ios::binary );
	fout.write((char*)& Int, n);
	fout.close();
	//push out
	char *temp = new char[n];
	ifstream fin(cache, ios::out | ios::binary);
	for (int i=0; i< sizeof(Int); ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();
	//the real one
	fout.open(file_name, ios::out | ios::binary|ios::app);
	for (int i = 0; i < n; ++i)
		fin.read((char*)& temp[n-i],1);
	fout.close();
	delete[] temp;
	return true;
}
bool writeBEFloat(float a, string file_name)
{
	//khay nho tam
	ofstream fout(cache, ios::out | ios::binary);
	fout.write((char*)& a, 4);
	fout.close();
	//push out
	char temp[4];
	ifstream fin(cache, ios::out | ios::binary);
	for (int i = 0; i < 4; ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();
	//the real one
	fout.open(file_name, ios::out | ios::binary | ios::app);
	for (int i = 0; i < 4; ++i)
		fin.read((char*)& temp[8 - i], 1);
	fout.close();
	return true;
}
bool writeBEDouble(double a, string file_name)
{
	//khay nho tam
	ofstream fout(cache, ios::out | ios::binary);
	fout.write((char*)& a, 8);
	fout.close();
	//push out
	char temp[8];
	ifstream fin(cache, ios::out | ios::binary);
	for (int i = 0; i < 8; ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();
	//the real one
	fout.open(file_name, ios::out | ios::binary | ios::app);
	for (int i = 0; i < 4; ++i)
		fin.read((char*)& temp[8 - i], 1);
	fout.close();
	return true;
}
void writeIntOverK(string file_name)
{
	cout << "WRITE INTEGER OVEER K\n";
	cout << "N (only choose 1->8 Byte(s)= ";
	int n;
	cin >> n;
	cout << "Int= ";
	int64_t base_10;
	cin >> base_10;
	cout <<	"K:= ";
	int k;
	cin >> k;
	base_10 += k;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	if (!LE_BE)
		writeLEInt(base_10, n, file_name);
	else
		writeBEInt(base_10, n, file_name);

}
void writeInt2Comp(string file_name) 
{
	cout << "Write Interger Two Complement\n ";
	cout << "N (only choose 1->8 Byte(s)= ";
	int n;
	cin >> n;
	cout << "Int= ";
	int64_t base_10;
	cin >> base_10;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	unsigned int two = ~base_10 + 1;
	if (!LE_BE)
			writeLEInt(two, n, file_name);
	else
			writeBEInt(two, n, file_name);
}
void writeReal(string file_name)
{
	cout << "Write Real number\n ";
	cout << "4\8 byte? ";
	int n;
	cin >> n;
	if (n == 4)
	{
		float a;
		cout << "float: ";
		cin >> a;
		cout << "LE or BE? (0 for LE / 1 for BE ) \n";
		bool LE_BE = 0; // kieu 
		cin >> LE_BE;
		if (!LE_BE)
			writeLEFloat(a, file_name);
		else
			writeBEFloat(a, file_name);
	}
	else
	{
		double b;
		cout << "float: ";
		cin >> b;
		cout << "LE or BE? (0 for LE / 1 for BE ) \n";
		bool LE_BE = 0; // kieu 
		cin >> LE_BE;
		if (!LE_BE)
			writeLEDouble(b, file_name);
		else
			writeBEDouble(b, file_name);
	}
}
void writeString(string file_name)
{
	cout << "Write string:";
	cout << "\n1. ASCII \n2.TF8 \n3.UTF16";
	int type2;
	cin >> type2;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	cout << "Input string:";
	string str;
	getline(cin, str);

	char none = '0';
	ofstream fout(file_name, ios::out | ios::binary);
	if (type2 == 3)
		if (LE_BE)
			for (int i = 0; i < str.length(); i = i + 2)
			{
				fout.write(&none, 1);
				fout.write(&str[i], 1);
			}
		else
			for (int i = 0; i < str.length(); i = i + 2)
			{
				fout.write(&none, 1);
				fout.write(&str[i], 1);
			}

	else
		for (int i = 0; i < str.length(); i++)
		{
			fout.write(&str[i], 1);
			fout.write(&none, 1);
		};
	fout.close();

}

void readReal(string file_name)
{
	cout << "Read Real number\n ";
	cout << "4\8 byte? ";
	int n;
	cin >> n;
	if (n == 4)
	{
		float a;
		cin >> a;
		cout << "LE or BE? (0 for LE / 1 for BE ) \n";
		bool LE_BE = 0; // kieu 
		cin >> LE_BE;
		if (!LE_BE)
			readLEFloat(a, file_name);
		else
			readBEFloat(a, file_name);
		cout << "float: " << setprecision(18) << a;
	}
	else
	{
		double b;
		cout << "float: ";
		cin >> b;
		cout << "LE or BE? (0 for LE / 1 for BE ) \n";
		bool LE_BE = 0; // kieu 
		cin >> LE_BE;
		if (!LE_BE)
			readLEDouble(b, file_name);
		else
			readBEDouble(b, file_name);
		cout << "double: " << setprecision(18) << b;
	}
}
bool readLEFloat(float real, string file_name)
{
	ifstream fout(file_name, ios::out | ios::binary);
	fout.read((char*)& real, sizeof(real));
	fout.close();
	return true;
}
bool readLEDouble(double real, string file_name)
{
	ifstream fout(file_name, ios::out | ios::binary | ios::app);
	fout.read((char*)& real, sizeof(real));
	fout.close();
	return true;
}
bool readBEFloat(float a, string file_name)
{
	//khay nho tam
	char temp[4];
	ifstream fin(file_name, ios::out | ios::binary);
	for (int i = 0; i < 4; ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();

	ofstream fout(cache, ios::out | ios::binary);
	for (int i = 0; i < 4; ++i)
		fin.read((char*)& temp[4 - i], 1);
	fout.close();
	ifstream fin(cache, ios::out | ios::binary);
	fin.read((char*)& a, 4);
	fin.close();
	return true;
}
bool readBEDouble(double a, string file_name)
{
	//khay nho tam
	char temp[8];
	
	ifstream fin(file_name, ios::out | ios::binary);
	for (int i = 0; i < 8; ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();

	
	ofstream fout(cache, ios::out | ios::binary);
	for (int i = 0; i < 8; ++i)
		fin.read((char*)& temp[8 - i], 1);
	fout.close();
	ifstream fin(cache, ios::out | ios::binary);
	fin.read((char*)& a, 8);
	fin.close();
	return true;
}
bool readBEInt(int64_t &Int, int n, string file_name)
{
	//khay nho tam
	char *temp = new char[n];
	ifstream fin(file_name, ios::out | ios::binary);
	for (int i = 0; i < sizeof(Int); ++i)
		fin.read((char*)& temp[i], 1);
	fin.close();

	ofstream fout(cache, ios::out | ios::binary);
	for (int i = 0; i < n; ++i)
		fin.read((char*)& temp[n - i], 1);
	fout.close();
	delete[] temp;
	ifstream fin(cache, ios::out | ios::binary);
	fin.read((char*)& Int, n);
	fin.close();
	return true;
}
bool readLEInt(int64_t &Int, int n, string file_name)
{
	ifstream fin(file_name, ios::out | ios::binary);
	fin.read((char*)& Int, n);
	fin.close();
	cout << Int;
	return true;
}

void readString(string file_name)
{
	cout << "Read string";
	cout << "\n1. ASCII \n2.TF8 \n3.UTF16";
	int type2;
	cin >> type2;

	cout << "Leght = ";
	int n;
	cin >> n;
	string str;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	char none = '0';
	ifstream fin(file_name, ios::in | ios::binary);
	if (type2 == 3)
		if (LE_BE)
			for (int i = 0; i < n; i = i + 2)
			{
				char temp;
				fin.read(&temp, 1);
				str.push_back(none);
				str.push_back(temp);
			}
		else
			for (int i = 0; i < n; i = i + 2)
			{
				char temp;
				fin.read(&temp, 1);
				str.push_back(temp);
				str.push_back(none);
			}
	else
		for (int i = 0; i < str.length(); i++)
			fin.read(&str[i], 1);
	fin.close();
	cout << "String:";
	for (int i = 0; i < str.length(); i++)
		cout << str[i];
}

void readIntOverK(string file_name)
{
	cout << "READ INTEGER OVEER K\n";
	cout << "N (only choose 1->8 Byte(s)= ";
	int n;
	cin >> n;
	int64_t base_10;
	cout << "K:= ";
	int k;
	cin >> k;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	if (!LE_BE)
		readLEInt(base_10, n, file_name);
	else
		readBEInt(base_10, n, file_name);
	base_10 -= k;
	cout << "int= "<< base_10;
}
void readInt2Comp(string file_name){
	cout << "Read Interger Two Complement\n ";
	cout << "N (only choose 1->8 Byte(s)= ";
	int n;
	cin >> n;
	int64_t base_10;
	cout << "LE or BE? (0 for LE / 1 for BE ) \n";
	bool LE_BE = 0; // kieu 
	cin >> LE_BE;
	int64_t two;
	if (!LE_BE)
		readLEInt(two, n, file_name);
	else
		readBEInt(two, n, file_name);
	base_10 = ~(two - 1);

	cout << "Int= " << base_10 ;


}
