#include "IntNum.h"

int main() {
	IntNum a;
	a.input();
	a.output();

	//getch();
	system("pause");
	return 0;
}